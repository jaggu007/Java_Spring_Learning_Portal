# Student Spring Boot REST API

A beginner-friendly REST API for the React Student Management demo.

## Requirements
- JDK 17 or newer
- Maven 3.6+ (or import the `pom.xml` into IntelliJ IDEA / Eclipse)

## Run
From this folder:
```bash
mvn spring-boot:run
```
API base URL: `http://localhost:8080/api/students`

The API seeds three students at startup and stores changes in memory. Restarting the app resets data.

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List all students |
| GET | `/api/students/{id}` | Fetch one student by ID |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/{id}` | Replace a student's details |
| DELETE | `/api/students/{id}` | Delete a student |

### Sample POST / PUT body
```json
{
  "name": "Aarav Gupta",
  "email": "aarav@example.com",
  "course": "B.Tech CSE"
}
```

### Test with curl
```bash
curl http://localhost:8080/api/students
curl http://localhost:8080/api/students/1

curl -X POST http://localhost:8080/api/students \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Aarav Gupta","email":"aarav@example.com","course":"B.Tech CSE"}'

curl -X PUT http://localhost:8080/api/students/1 \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Aditi Sharma","email":"aditi@example.com","course":"B.Tech CSE"}'

curl -i -X DELETE http://localhost:8080/api/students/1
```

## Classroom concepts demonstrated
- `@RestController`
- `@RequestMapping`
- `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`
- `@PathVariable`, `@RequestBody`
- JSON request/response handling
- HTTP status codes (`201`, `200`, `204`, `400`, `404`)
- CORS for the React dev server (`localhost:5173`)
