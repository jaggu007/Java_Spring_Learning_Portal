package edu.kiet.demo.student;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "http://localhost:5173")
public class StudentController {
    private final Map<Long, Student> students = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong();

    public StudentController() {
        addSeed("Aditi Sharma", "aditi@example.com", "B.Tech CSE");
        addSeed("Rahul Verma", "rahul@example.com", "B.Tech CSE");
        addSeed("Meera Singh", "meera@example.com", "B.Tech AI & ML");
    }

    private void addSeed(String name, String email, String course) {
        long id = idGenerator.incrementAndGet();
        students.put(id, new Student(id, name, email, course));
    }

    @GetMapping
    public List<Student> getAllStudents() {
        List<Student> result = new ArrayList<>(students.values());
        result.sort(Comparator.comparing(Student::getId));
        return result;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Student student = students.get(id);
        return student == null ? ResponseEntity.notFound().build() : ResponseEntity.ok(student);
    }

    @PostMapping
    public ResponseEntity<Student> createStudent(@RequestBody Student input) {
        if (isBlank(input.getName()) || isBlank(input.getEmail()) || isBlank(input.getCourse())) {
            return ResponseEntity.badRequest().build();
        }
        long id = idGenerator.incrementAndGet();
        Student student = new Student(id, input.getName().trim(), input.getEmail().trim(), input.getCourse().trim());
        students.put(id, student);
        return ResponseEntity.status(HttpStatus.CREATED).body(student);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student input) {
        if (!students.containsKey(id)) return ResponseEntity.notFound().build();
        if (isBlank(input.getName()) || isBlank(input.getEmail()) || isBlank(input.getCourse())) {
            return ResponseEntity.badRequest().build();
        }
        Student updated = new Student(id, input.getName().trim(), input.getEmail().trim(), input.getCourse().trim());
        students.put(id, updated);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStudent(@PathVariable Long id) {
        return students.remove(id) == null
                ? ResponseEntity.notFound().build()
                : ResponseEntity.noContent().build();
    }

    private boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}