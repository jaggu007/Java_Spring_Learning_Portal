package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @Autowired
    private Student student;

    @GetMapping("/")
    public String home() {
        return "Welcome to Spring Boot Again!";
    }

    @GetMapping("/student")
    public String getStudent() {
        return "Student bean injected successfully: " + student;
    }

    
    @PostMapping("/student")
    public String addStudent(@RequestBody Student student) {

        return "Student added successfully! Name: "
                + student.getName()
                + ", Roll No: "
                + student.getRollNo()
                + ", Course: "
                + student.getCourse();
    }
}