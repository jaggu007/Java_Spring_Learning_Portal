package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	

    private List<Student> students = new ArrayList<>();

    // GET: Retrieve all students
    @GetMapping("/students")
    public List<Student> getStudents() {
        return students;
    }
    
    @GetMapping("/students/{rollNo}")
    public Student getStudentById(@PathVariable int rollNo) {

        for (Student student : students) {

            if (student.getRollNo() == rollNo) {
                return student;
            }
        }

        return null;
    }

    // POST: Add a new student
    @PostMapping("/students")
    public String addStudent(@RequestBody Student student) {

        students.add(student);
        
        return "Student added successfully! ";
    }
    
 // PUT: Update an existing student
    @PutMapping("/students/{rollNo}")
    public String updateStudent(
            @PathVariable int rollNo,
            @RequestBody Student updatedStudent) {

        for (Student student : students) {

            if (student.getRollNo() == rollNo) {

                student.setName(updatedStudent.getName());
                student.setCourse(updatedStudent.getCourse());

                return "Student updated successfully!";
            }
        }

        return "Student not found!";
    }
    
 // DELETE: Remove a student using roll number
    @DeleteMapping("/students/{rollNo}")
    public String deleteStudent(@PathVariable int rollNo) {

        for (Student student : students) {

            if (student.getRollNo() == rollNo) {

                students.remove(student);

                return "Student deleted successfully!";
            }
        }

        return "Student not found!";
    }
}