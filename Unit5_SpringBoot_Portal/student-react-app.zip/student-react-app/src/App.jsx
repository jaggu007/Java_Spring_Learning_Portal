import { useEffect, useState } from "react";

const API = "http://localhost:8080/api/students";

export default function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", course: "" });
  const [message, setMessage] = useState("Connecting to Spring Boot API...");
  const [busy, setBusy] = useState(false);

  async function loadStudents() {
    try {
      const response = await fetch(API);
      if (!response.ok) throw new Error(`API returned ${response.status}`);
      setStudents(await response.json());
      setMessage("Connected to Spring Boot API");
    } catch {
      setMessage("Cannot reach API. Start the Spring Boot app on port 8080.");
    }
  }

  useEffect(() => { loadStudents(); }, []);

  function updateField(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function addStudent(event) {
    event.preventDefault();
    setBusy(true);
    try {
      const response = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      if (!response.ok) throw new Error("Could not add student");
      setForm({ name: "", email: "", course: "" });
      setMessage("Student added successfully");
      await loadStudents();
    } catch {
      setMessage("Could not add student. Check that the API is running.");
    } finally {
      setBusy(false);
    }
  }

  async function deleteStudent(id) {
    try {
      const response = await fetch(`${API}/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Delete failed");
      setMessage(`Student #${id} deleted`);
      await loadStudents();
    } catch {
      setMessage("Could not delete student.");
    }
  }

  return (
    <main className="container">
      <header>
        <span className="eyebrow">REACT + SPRING BOOT</span>
        <h1>Student Management</h1>
        <p>A small classroom demo of a React UI calling a REST API.</p>
      </header>

      <div className="status" role="status">{message}</div>

      <section className="panel">
        <h2>Add a student</h2>
        <form onSubmit={addStudent} className="student-form">
          <label>Full name
            <input name="name" value={form.name} onChange={updateField} required placeholder="e.g. Aditi Sharma" />
          </label>
          <label>Email
            <input name="email" type="email" value={form.email} onChange={updateField} required placeholder="aditi@example.com" />
          </label>
          <label>Course
            <input name="course" value={form.course} onChange={updateField} required placeholder="e.g. B.Tech CSE" />
          </label>
          <button disabled={busy} type="submit">{busy ? "Adding..." : "Add student"}</button>
        </form>
      </section>

      <section className="panel">
        <div className="list-heading">
          <div><h2>Class roster</h2><p>{students.length} student(s)</p></div>
          <button className="secondary" onClick={loadStudents}>Refresh</button>
        </div>
        {students.length === 0 ? <p className="empty">No students found. Add the first student above.</p> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Course</th><th>Action</th></tr></thead>
              <tbody>{students.map(student => (
                <tr key={student.id}>
                  <td>#{student.id}</td><td>{student.name}</td><td>{student.email}</td><td>{student.course}</td>
                  <td><button className="delete" onClick={() => deleteStudent(student.id)}>Delete</button></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        )}
      </section>
      <footer>Demo note: data is stored in memory and resets when the API restarts.</footer>
    </main>
  );
}