# Student React App

A Vite + React UI that calls the separate Spring Boot REST API.

## Requirements
- Node.js 20.19+ or 22.12+ recommended
- Spring Boot API running at `http://localhost:8080`

## Run
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually `http://localhost:5173`).

## API used
- `GET http://localhost:8080/api/students`
- `GET http://localhost:8080/api/students/{id}`
- `POST http://localhost:8080/api/students`
- `PUT http://localhost:8080/api/students/{id}`
- `DELETE http://localhost:8080/api/students/{id}`

The sample backend stores data in memory; restarting it resets the list.
